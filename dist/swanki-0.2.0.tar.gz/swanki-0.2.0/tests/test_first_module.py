from my_package.first_module import a_useful_function


def test_a_useful_function() -> None:
    assert a_useful_function() is None
