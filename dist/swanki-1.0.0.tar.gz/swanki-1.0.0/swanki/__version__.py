__version__ = "1.0.0"  # Linked to semantic-release in toml
